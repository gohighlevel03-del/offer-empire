export enum View {
  DASHBOARD = 'DASHBOARD',
  OFFER_FINDER = 'OFFER_FINDER',
  MARKETING_LAB = 'MARKETING_LAB',
  MENTOR = 'MENTOR',
  COMPLIANCE = 'COMPLIANCE',
  WALLET = 'WALLET',
  LAUNCH_PLAN = 'LAUNCH_PLAN',
  WEBSITE_BUILDER = 'WEBSITE_BUILDER',
  YOUTUBE_AGENT = 'YOUTUBE_AGENT',
  LEAD_GEN = 'LEAD_GEN'
}

export interface AffiliateOffer {
  title: string;
  network: string;
  payout: string;
  link: string;
  description: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export enum MarketingTool {
  COPY_GEN = 'COPY_GEN',
  IMAGE_EDIT = 'IMAGE_EDIT',
  VIDEO_AVATAR = 'VIDEO_AVATAR'
}

export interface GlobalState {
  balance: number;
  leads: number;
  activeCampaigns: number;
}

export interface Lead {
  name: string;
  source: string;
  contactInfo: string;
  status: 'New' | 'Contacted' | 'Converted';
}

export interface YouTubeTask {
  id: string;
  type: 'RESEARCH' | 'SCRIPT' | 'VIDEO' | 'UPLOAD';
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  data: any;
}