import React, { useState } from 'react';
import { findOffersWithGrounding } from '../services/geminiService';
import { Search, Loader2, ExternalLink, TrendingUp, Globe, ShieldCheck } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const topNetworks = [
  { name: 'ClickBank', type: 'Digital & Health', url: 'https://www.clickbank.com/', desc: 'Best for beginners. High commissions.' },
  { name: 'MaxWeb', type: 'VSL / Nutra', url: 'https://maxweb.com/', desc: 'Top converting VSL offers.' },
  { name: 'JVZoo', type: 'Software & IM', url: 'https://www.jvzoo.com/', desc: 'Great for software launches.' },
  { name: 'WarriorPlus', type: 'MMO / BizOpp', url: 'https://warriorplus.com/', desc: 'Make money online niche.' },
  { name: 'ShareASale', type: 'Retail', url: 'https://www.shareasale.com/', desc: 'Physical products & fashion.' },
  { name: 'CJ Affiliate', type: 'Big Brands', url: 'https://www.cj.com/', desc: 'Premium brand partnerships.' },
  { name: 'PartnerStack', type: 'SaaS / Tech', url: 'https://partnerstack.com/', desc: 'B2B software programs.' },
  { name: 'Impact', type: 'Lifestyle', url: 'https://impact.com/', desc: 'Modern direct partnerships.' },
];

const OfferFinder: React.FC = () => {
  const [niche, setNiche] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ text: string; sources: any[] } | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!niche) return;
    setLoading(true);
    try {
      const data = await findOffersWithGrounding(niche);
      setResult(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="bg-card border border-gray-700 rounded-xl p-8">
        <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
          <Search className="text-primary" /> Offer Finder AI
        </h2>
        <p className="text-gray-400 mb-6">
          Uses Google Search Grounding to scan networks for high-ticket, trending offers in real-time.
        </p>

        <form onSubmit={handleSearch} className="relative flex items-center">
          <input
            type="text"
            value={niche}
            onChange={(e) => setNiche(e.target.value)}
            placeholder="Enter niche (e.g., Crypto, Weight Loss, AI Tools)..."
            className="w-full bg-gray-900 text-white border border-gray-700 rounded-lg py-4 pl-4 pr-32 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
          />
          <button
            type="submit"
            disabled={loading}
            className="absolute right-2 bg-gradient-to-r from-primary to-green-600 hover:from-green-400 hover:to-green-500 text-darker font-bold py-2 px-6 rounded-md transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : 'Scrape'}
          </button>
        </form>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-card border border-gray-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 border-b border-gray-700 pb-2">
              Analysis Result
            </h3>
            <div className="prose prose-invert max-w-none text-sm text-gray-300">
              <ReactMarkdown>{result.text}</ReactMarkdown>
            </div>
          </div>

          <div className="bg-card border border-gray-700 rounded-xl p-6 h-fit">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <TrendingUp size={18} className="text-secondary" /> Source Links
            </h3>
            <div className="space-y-3">
              {result.sources && result.sources.length > 0 ? (
                result.sources.map((source, idx) => (
                  <div key={idx} className="bg-gray-900 p-3 rounded-lg border border-gray-800 hover:border-gray-600 transition-colors">
                    {source.web?.uri ? (
                        <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="flex items-start gap-2 group">
                        <ExternalLink size={14} className="mt-1 text-primary group-hover:text-white" />
                        <div>
                            <p className="text-xs font-bold text-gray-300 group-hover:text-primary truncate w-48">
                            {source.web.title || 'Source Link'}
                            </p>
                            <p className="text-[10px] text-gray-500 truncate w-48">{source.web.uri}</p>
                        </div>
                        </a>
                    ) : (
                        <span className="text-xs text-gray-500">Source info unavailable</span>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No direct sources returned.</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Top Networks Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Globe size={20} className="text-blue-400" /> Top Affiliate Networks
          </h3>
          <span className="text-xs text-gray-500 flex items-center gap-1"><ShieldCheck size={12} /> Vetted Platforms</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {topNetworks.map((net, i) => (
            <div key={i} className="bg-gray-900 border border-gray-800 p-4 rounded-xl hover:border-primary/50 transition-all group relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <ExternalLink size={14} className="text-gray-400" />
              </div>
              <div className="mb-3">
                 <h4 className="font-bold text-white text-lg">{net.name}</h4>
                 <span className="text-xs bg-gray-800 text-primary px-2 py-1 rounded border border-gray-700">{net.type}</span>
              </div>
              <p className="text-gray-400 text-xs mb-4 h-8">{net.desc}</p>
              <a 
                href={net.url} 
                target="_blank" 
                rel="noreferrer"
                className="block w-full text-center bg-gray-800 hover:bg-primary hover:text-darker text-white text-sm font-bold py-2 rounded transition-colors"
              >
                Sign Up
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OfferFinder;