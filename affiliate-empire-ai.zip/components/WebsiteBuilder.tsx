import React, { useState } from 'react';
import { generateWebsiteContent } from '../services/geminiService';
import { LayoutTemplate, Wand2, Save, Eye, MousePointer2, Type, Image as ImageIcon, Layout } from 'lucide-react';

const WebsiteBuilder: React.FC = () => {
  const [niche, setNiche] = useState('');
  const [loading, setLoading] = useState(false);
  const [content, setContent] = useState({
    headline: 'Your High Converting Headline Goes Here',
    body: '<p>This is where your persuasive copy will live. Use the AI generator to fill this with gold.</p>',
    cta: 'Click Here to Buy Now',
    seoTitle: 'Landing Page Title',
    seoDesc: 'Description for search engines.'
  });

  const handleGenerate = async () => {
    if (!niche) return;
    setLoading(true);
    try {
      const generated = await generateWebsiteContent(niche, 'SALES');
      setContent(generated);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAddForm = () => {
    const formHtml = `
      <div class="my-8 p-8 bg-gray-50 border-2 border-dashed border-blue-200 rounded-xl text-center group relative hover:border-blue-400 transition-all">
        <div class="mb-6">
          <h3 class="text-2xl font-bold text-gray-900 mb-2">🚀 Join The VIP List</h3>
          <p class="text-gray-600">Get exclusive access to our best strategies.</p>
        </div>
        <form class="max-w-md mx-auto space-y-4">
          <div>
            <input type="text" placeholder="Enter your name" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" />
          </div>
          <div>
            <input type="email" placeholder="Enter your best email" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" />
          </div>
          <button type="button" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-lg shadow-lg transform transition hover:-translate-y-1">
            YES! Send Me The Details
          </button>
        </form>
        <p class="text-xs text-gray-400 mt-4">🔒 Your information is 100% secure</p>
      </div>
    `;
    
    setContent(prev => ({
      ...prev,
      body: prev.body + formHtml
    }));
  };

  const handleAddHeadline = () => {
    const html = `<h2 class="text-3xl font-bold text-gray-800 my-6">New Section Headline</h2>`;
    setContent(prev => ({ ...prev, body: prev.body + html }));
  };

  const handleAddImage = () => {
    const html = `
      <div class="my-8 relative group rounded-xl overflow-hidden shadow-xl bg-gray-100 h-64 flex items-center justify-center">
         <span class="text-gray-400 font-medium flex items-center gap-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg> Image Placeholder</span>
      </div>
    `;
    setContent(prev => ({ ...prev, body: prev.body + html }));
  };

  const handleAddButton = () => {
    const html = `
      <div class="text-center my-6">
         <button class="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-full shadow-md transition-all transform hover:scale-105">
           Get Started Now
         </button>
      </div>
    `;
    setContent(prev => ({ ...prev, body: prev.body + html }));
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-6 max-w-7xl mx-auto">
      {/* Sidebar Controls */}
      <div className="w-full lg:w-80 bg-card border border-gray-700 rounded-xl p-6 flex flex-col gap-6 h-fit">
        <div>
          <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
            <LayoutTemplate className="text-primary" /> Funnel Builder
          </h2>
          <p className="text-gray-400 text-xs">Drag & drop interface initialized. Use AI to populate.</p>
        </div>

        <div className="space-y-3">
          <label className="text-xs font-semibold text-gray-400 uppercase">AI Content Generator</label>
          <input
            type="text"
            value={niche}
            onChange={(e) => setNiche(e.target.value)}
            placeholder="Enter niche (e.g. Keto, Crypto)..."
            className="w-full bg-gray-900 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:border-primary focus:outline-none"
          />
          <button 
            onClick={handleGenerate}
            disabled={loading}
            className="w-full bg-secondary hover:bg-secondary/80 text-white font-bold py-2 rounded flex items-center justify-center gap-2 text-sm disabled:opacity-50 transition-all"
          >
            {loading ? <Wand2 className="animate-spin" size={14} /> : <Wand2 size={14} />}
            Auto-Generate Page
          </button>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold text-gray-400 uppercase">Elements</label>
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={handleAddHeadline}
              className="p-3 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 flex flex-col items-center gap-1 transition-colors active:scale-95"
            >
              <Type size={16} className="text-primary" />
              <span className="text-[10px] text-gray-300">Headline</span>
            </button>
            <button 
              onClick={handleAddImage}
              className="p-3 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 flex flex-col items-center gap-1 transition-colors active:scale-95"
            >
              <ImageIcon size={16} className="text-blue-400" />
              <span className="text-[10px] text-gray-300">Image</span>
            </button>
            <button 
              onClick={handleAddButton}
              className="p-3 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 flex flex-col items-center gap-1 transition-colors active:scale-95"
            >
              <MousePointer2 size={16} className="text-green-400" />
              <span className="text-[10px] text-gray-300">Button</span>
            </button>
            <button 
              onClick={handleAddForm}
              className="p-3 bg-gray-800 hover:bg-gray-700 rounded border border-gray-700 flex flex-col items-center gap-1 transition-colors active:scale-95"
            >
              <Layout size={16} className="text-purple-400" />
              <span className="text-[10px] text-gray-300">Form</span>
            </button>
          </div>
        </div>

        <div className="space-y-3 pt-4 border-t border-gray-700">
          <label className="text-xs font-semibold text-gray-400 uppercase">SEO Optimization</label>
          <div className="space-y-2">
             <div className="bg-gray-900 p-2 rounded border border-gray-800">
                <p className="text-[10px] text-gray-500">Title Tag</p>
                <p className="text-xs text-white truncate">{content.seoTitle}</p>
             </div>
             <div className="bg-gray-900 p-2 rounded border border-gray-800">
                <p className="text-[10px] text-gray-500">Meta Description</p>
                <p className="text-xs text-white truncate">{content.seoDesc}</p>
             </div>
          </div>
        </div>
      </div>

      {/* Canvas Preview */}
      <div className="flex-1 bg-gray-900 border border-gray-700 rounded-xl flex flex-col overflow-hidden">
        <div className="bg-gray-800 p-3 border-b border-gray-700 flex justify-between items-center">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-1 px-3 py-1 bg-dark rounded text-xs text-white hover:bg-black transition-colors"><Eye size={12}/> Preview</button>
            <button className="flex items-center gap-1 px-3 py-1 bg-primary text-darker font-bold rounded text-xs hover:bg-green-400 transition-colors"><Save size={12}/> Publish</button>
          </div>
        </div>
        
        <div className="flex-1 p-8 overflow-y-auto bg-white text-black relative">
          {/* Simulated Canvas */}
          <div className="max-w-3xl mx-auto border-2 border-dashed border-transparent hover:border-blue-300 transition-all p-4 rounded group">
             <h1 className="text-4xl md:text-6xl font-bold text-center mb-6 text-gray-900 outline-none focus:ring-2 ring-blue-500 rounded px-2" contentEditable suppressContentEditableWarning>
               {content.headline}
             </h1>
          </div>

          <div className="max-w-2xl mx-auto my-8 border-2 border-dashed border-transparent hover:border-blue-300 transition-all p-4 rounded">
             <div className="prose prose-lg text-gray-700" dangerouslySetInnerHTML={{ __html: content.body }} />
          </div>

          <div className="max-w-md mx-auto text-center border-2 border-dashed border-transparent hover:border-blue-300 transition-all p-4 rounded">
             <button className="bg-red-600 hover:bg-red-700 text-white font-bold text-2xl py-4 px-12 rounded-full shadow-lg transform hover:scale-105 transition-all">
               {content.cta}
             </button>
             <p className="text-xs text-gray-500 mt-2">100% Secure Checkout - 30 Day Guarantee</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WebsiteBuilder;