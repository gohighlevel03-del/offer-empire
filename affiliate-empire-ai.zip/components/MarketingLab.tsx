import React, { useState } from 'react';
import { MarketingTool } from '../types';
import { generateVeoVideo, editImage, generateMarketingCopy } from '../services/geminiService';
import { Clapperboard, Image as ImageIcon, PenTool, Loader2, PlayCircle, Upload, Wand2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const MarketingLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<MarketingTool>(MarketingTool.VIDEO_AVATAR);
  
  // Veo State
  const [veoPrompt, setVeoPrompt] = useState('');
  const [veoImage, setVeoImage] = useState<string | null>(null);
  const [veoResult, setVeoResult] = useState<string | null>(null);
  const [veoLoading, setVeoLoading] = useState(false);

  // Image Edit State
  const [editImageFile, setEditImageFile] = useState<string | null>(null);
  const [editPrompt, setEditPrompt] = useState('');
  const [editResult, setEditResult] = useState<string | null>(null);
  const [editLoading, setEditLoading] = useState(false);

  // Copy State
  const [copyPrompt, setCopyPrompt] = useState('');
  const [copyResult, setCopyResult] = useState('');
  const [copyLoading, setCopyLoading] = useState(false);

  // Helpers
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        // Strip prefix for API usage usually, but keep for preview
        setter(base64); 
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVeoGenerate = async () => {
    setVeoLoading(true);
    setVeoResult(null);
    try {
      // Pass base64 data without prefix for API
      const imageBytes = veoImage ? veoImage.split(',')[1] : undefined;
      const url = await generateVeoVideo(veoPrompt, imageBytes);
      setVeoResult(url);
    } catch (error) {
      console.error(error);
      alert("Veo generation failed. Check console or billing.");
    } finally {
      setVeoLoading(false);
    }
  };

  const handleImageEdit = async () => {
    if (!editImageFile || !editPrompt) return;
    setEditLoading(true);
    try {
      const imageBytes = editImageFile.split(',')[1];
      const mimeType = editImageFile.split(';')[0].split(':')[1];
      const result = await editImage(imageBytes, mimeType, editPrompt);
      setEditResult(result);
    } catch (error) {
      console.error(error);
      alert("Image edit failed.");
    } finally {
      setEditLoading(false);
    }
  };

  const handleCopyGen = async () => {
    if (!copyPrompt) return;
    setCopyLoading(true);
    try {
      const res = await generateMarketingCopy(copyPrompt);
      setCopyResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setCopyLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-100px)] flex flex-col">
      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-900 p-1 rounded-xl border border-gray-800 mb-6 w-fit">
        <button
          onClick={() => setActiveTab(MarketingTool.VIDEO_AVATAR)}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === MarketingTool.VIDEO_AVATAR ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'
          }`}
        >
          <Clapperboard size={16} /> Veo Studio
        </button>
        <button
          onClick={() => setActiveTab(MarketingTool.IMAGE_EDIT)}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === MarketingTool.IMAGE_EDIT ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'
          }`}
        >
          <ImageIcon size={16} /> Creative Editor
        </button>
        <button
          onClick={() => setActiveTab(MarketingTool.COPY_GEN)}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === MarketingTool.COPY_GEN ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'
          }`}
        >
          <PenTool size={16} /> Copywriter
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 bg-card border border-gray-700 rounded-xl p-6 overflow-y-auto relative">
        
        {/* VEO SECTION */}
        {activeTab === MarketingTool.VIDEO_AVATAR && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">AI Avatar & Video Ads</h2>
                <p className="text-gray-400 text-sm">Generate high-quality video assets using <span className="text-secondary font-bold">Veo 3.1</span>. Perfect for TikTok/Shorts or VSLs.</p>
              </div>

              <div className="space-y-4">
                <div className="bg-dark p-4 rounded-lg border border-gray-800 border-dashed text-center">
                   {veoImage ? (
                     <div className="relative h-48 w-full">
                       <img src={veoImage} alt="Source" className="h-full w-full object-cover rounded-md" />
                       <button onClick={() => setVeoImage(null)} className="absolute top-2 right-2 bg-red-500/80 p-1 rounded-full text-white hover:bg-red-600">X</button>
                     </div>
                   ) : (
                     <label className="cursor-pointer flex flex-col items-center justify-center h-32">
                       <Upload className="text-gray-500 mb-2" />
                       <span className="text-sm text-gray-400">Upload source image (optional)</span>
                       <input type="file" className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, setVeoImage)} />
                     </label>
                   )}
                </div>

                <textarea 
                  className="w-full bg-gray-900 border border-gray-700 rounded-lg p-4 text-white focus:border-primary focus:ring-1 focus:ring-primary h-32 resize-none"
                  placeholder="Describe the video... e.g., 'A cyberpunk marketer talking about affiliate offers in a neon room'"
                  value={veoPrompt}
                  onChange={(e) => setVeoPrompt(e.target.value)}
                />

                <button 
                  onClick={handleVeoGenerate}
                  disabled={veoLoading || !veoPrompt}
                  className="w-full bg-secondary hover:bg-secondary/80 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  {veoLoading ? <><Loader2 className="animate-spin" /> Generating (this takes time)...</> : <><Clapperboard size={18} /> Generate Video (Veo)</>}
                </button>
              </div>
            </div>

            <div className="bg-darker rounded-xl border border-gray-800 flex items-center justify-center relative overflow-hidden min-h-[300px]">
              {veoLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-10 p-8 text-center">
                  <Loader2 className="animate-spin text-secondary mb-4" size={48} />
                  <p className="text-gray-300 animate-pulse">Veo is dreaming up your video...</p>
                </div>
              )}
              {veoResult ? (
                <video controls src={veoResult} className="w-full h-full object-contain" autoPlay loop />
              ) : (
                <div className="text-center text-gray-600">
                  <PlayCircle size={64} className="mx-auto mb-4 opacity-20" />
                  <p>Video preview will appear here</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* IMAGE EDIT SECTION */}
        {activeTab === MarketingTool.IMAGE_EDIT && (
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
             <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">Ad Creative Editor</h2>
                  <p className="text-gray-400 text-sm">Use <span className="text-secondary font-bold">Gemini Flash Image</span> to tweak ad creatives instantly.</p>
                </div>

                <div className="bg-dark p-4 rounded-lg border border-gray-800 border-dashed text-center min-h-[200px] flex flex-col justify-center">
                   {editImageFile ? (
                     <div className="relative w-full">
                       <img src={editImageFile} alt="Edit Source" className="max-h-64 mx-auto rounded-md" />
                       <button onClick={() => setEditImageFile(null)} className="absolute top-2 right-2 bg-red-500/80 p-1 rounded-full text-white hover:bg-red-600">X</button>
                     </div>
                   ) : (
                     <label className="cursor-pointer flex flex-col items-center justify-center h-full">
                       <Upload className="text-gray-500 mb-2" />
                       <span className="text-sm text-gray-400">Upload Ad Image</span>
                       <input type="file" className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, setEditImageFile)} />
                     </label>
                   )}
                </div>

                <div className="flex gap-2">
                  <input 
                    type="text"
                    className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-4 text-white focus:border-primary focus:outline-none"
                    placeholder="e.g., 'Add a Buy Now button', 'Make it black and white'"
                    value={editPrompt}
                    onChange={(e) => setEditPrompt(e.target.value)}
                  />
                  <button 
                    onClick={handleImageEdit}
                    disabled={editLoading || !editImageFile}
                    className="bg-primary hover:bg-green-400 text-darker font-bold px-6 rounded-lg flex items-center justify-center disabled:opacity-50"
                  >
                    {editLoading ? <Loader2 className="animate-spin" /> : <Wand2 size={18} />}
                  </button>
                </div>
             </div>

             <div className="bg-darker rounded-xl border border-gray-800 flex items-center justify-center p-4">
                {editLoading ? (
                   <Loader2 className="animate-spin text-primary" size={48} />
                ) : editResult ? (
                   <img src={editResult} alt="Edited Result" className="max-h-full max-w-full rounded-lg shadow-lg" />
                ) : (
                   <p className="text-gray-600 text-sm">Edited image will appear here</p>
                )}
             </div>
           </div>
        )}

        {/* COPYWRITER SECTION */}
        {activeTab === MarketingTool.COPY_GEN && (
          <div className="h-full flex flex-col space-y-4">
             <div>
                <h2 className="text-2xl font-bold text-white mb-2">Direct Response Copywriter</h2>
                <p className="text-gray-400 text-sm">Generate funnels, email swipes, and ad copy with <span className="text-secondary font-bold">Gemini Pro</span>.</p>
              </div>
             
             <div className="flex gap-4">
                <textarea 
                    className="flex-1 h-32 bg-gray-900 border border-gray-700 rounded-lg p-4 text-white focus:border-primary focus:ring-1 focus:ring-primary resize-none"
                    placeholder="Product: Crypto Course. Goal: High conversion email. Tone: Urgent."
                    value={copyPrompt}
                    onChange={(e) => setCopyPrompt(e.target.value)}
                  />
                 <button 
                  onClick={handleCopyGen}
                  disabled={copyLoading}
                  className="w-32 bg-gradient-to-b from-secondary to-indigo-900 hover:from-indigo-500 hover:to-indigo-800 text-white font-bold rounded-lg flex flex-col items-center justify-center gap-2 disabled:opacity-50"
                >
                  {copyLoading ? <Loader2 className="animate-spin" /> : <><PenTool size={24} /> Write</>}
                </button>
             </div>

             <div className="flex-1 bg-gray-900 rounded-lg border border-gray-800 p-6 overflow-y-auto">
                {copyResult ? (
                   <div className="prose prose-invert max-w-none">
                     <ReactMarkdown>{copyResult}</ReactMarkdown>
                   </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-600">
                    <p>Generated copy appears here...</p>
                  </div>
                )}
             </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default MarketingLab;