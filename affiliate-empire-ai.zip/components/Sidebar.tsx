import React from 'react';
import { View } from '../types';
import { 
  LayoutDashboard, 
  Search, 
  Beaker, 
  Bot, 
  ShieldCheck, 
  Wallet, 
  Rocket,
  LayoutTemplate,
  Youtube,
  Users
} from 'lucide-react';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const menuItems = [
    { id: View.DASHBOARD, label: 'Empire Dashboard', icon: LayoutDashboard },
    { id: View.OFFER_FINDER, label: 'Offer Finder AI', icon: Search },
    { id: View.WEBSITE_BUILDER, label: 'Funnel Builder', icon: LayoutTemplate },
    { id: View.YOUTUBE_AGENT, label: 'YouTube Agent', icon: Youtube },
    { id: View.LEAD_GEN, label: 'Lead Scraper', icon: Users },
    { id: View.MARKETING_LAB, label: 'Creative Lab', icon: Beaker },
    { id: View.MENTOR, label: 'Hustler Mentor', icon: Bot },
    { id: View.COMPLIANCE, label: 'Compliance Check', icon: ShieldCheck },
    { id: View.LAUNCH_PLAN, label: 'Launch Strategy', icon: Rocket },
    { id: View.WALLET, label: 'Payments', icon: Wallet },
  ];

  return (
    <div className="w-20 lg:w-64 bg-darker border-r border-gray-800 flex flex-col h-screen fixed left-0 top-0 z-50">
      <div className="p-6 flex items-center justify-center lg:justify-start border-b border-gray-800">
        <div className="h-8 w-8 bg-primary rounded-md mr-0 lg:mr-3 animate-pulse"></div>
        <span className="text-xl font-bold text-white hidden lg:block tracking-wider">EMPIRE<span className="text-primary">.AI</span></span>
      </div>
      
      <nav className="flex-1 py-6 space-y-1 px-3 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 group ${
                isActive 
                  ? 'bg-primary/10 text-primary border border-primary/20 shadow-[0_0_15px_rgba(0,255,157,0.1)]' 
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <Icon size={20} className={`${isActive ? 'text-primary' : 'group-hover:text-white'}`} />
              <span className="ml-3 hidden lg:block font-medium text-sm">{item.label}</span>
              {isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary hidden lg:block shadow-[0_0_8px_rgba(0,255,157,0.8)]" />}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-800 bg-darker z-10">
        <div className="bg-gray-900 rounded-lg p-3 border border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-secondary to-blue-600 flex items-center justify-center text-xs font-bold">
              ME
            </div>
            <div className="hidden lg:block">
              <p className="text-sm text-white font-medium">Admin Access</p>
              <p className="text-xs text-primary">Tier 3: Emperor</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;