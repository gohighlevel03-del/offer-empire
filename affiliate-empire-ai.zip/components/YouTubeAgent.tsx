import React, { useState } from 'react';
import { researchYouTubeTrends, generateVideoScript, generateVeoVideo, generateReply } from '../services/geminiService';
import { Youtube, TrendingUp, FileVideo, Video, MessageSquare, Loader2, UploadCloud, PlayCircle, Settings, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const YouTubeAgent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'RESEARCH' | 'CREATE' | 'MANAGE'>('RESEARCH');
  
  // Research State
  const [niche, setNiche] = useState('');
  const [trends, setTrends] = useState<{text: string, ideas: string[]} | null>(null);
  const [loadingTrends, setLoadingTrends] = useState(false);

  // Creation State
  const [scriptTopic, setScriptTopic] = useState('');
  const [script, setScript] = useState('');
  const [generatingScript, setGeneratingScript] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');
  const [generatingVideo, setGeneratingVideo] = useState(false);

  // Veo Options
  const [cinematicMode, setCinematicMode] = useState(true);
  const [highQuality, setHighQuality] = useState(true);

  // Manage State
  const [commentReply, setCommentReply] = useState('');
  
  const handleResearch = async () => {
    if (!niche) return;
    setLoadingTrends(true);
    try {
      const res = await researchYouTubeTrends(niche);
      setTrends(res);
    } catch (e) { console.error(e); }
    finally { setLoadingTrends(false); }
  };

  const handleScript = async () => {
    if (!scriptTopic) return;
    setGeneratingScript(true);
    try {
      const res = await generateVideoScript(scriptTopic);
      setScript(res);
    } catch (e) { console.error(e); }
    finally { setGeneratingScript(false); }
  };

  const handleVideo = async () => {
    if (!scriptTopic) return;
    setGeneratingVideo(true);
    try {
      const styles = [];
      if (cinematicMode) styles.push('cinematic lighting, dramatic, movie quality');
      if (highQuality) styles.push('4k resolution, highly detailed, sharp focus');
      
      const prompt = `A professional YouTube video intro about ${scriptTopic}. ${styles.join(', ')}`;

      // Use Veo to generate a video based on the topic
      const res = await generateVeoVideo(prompt);
      setVideoUrl(res);
    } catch (e) { console.error(e); }
    finally { setGeneratingVideo(false); }
  };

  return (
    <div className="h-full flex flex-col max-w-6xl mx-auto bg-card border border-gray-700 rounded-xl overflow-hidden">
      {/* Header Tabs */}
      <div className="bg-gray-900 border-b border-gray-700 p-4 flex items-center gap-6">
        <div className="flex items-center gap-2 text-red-500 font-bold text-lg mr-8">
          <Youtube size={24} /> Channel Agent
        </div>
        <button 
          onClick={() => setActiveTab('RESEARCH')} 
          className={`flex items-center gap-2 text-sm font-medium transition-colors ${activeTab === 'RESEARCH' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <TrendingUp size={16} /> Research
        </button>
        <button 
          onClick={() => setActiveTab('CREATE')} 
          className={`flex items-center gap-2 text-sm font-medium transition-colors ${activeTab === 'CREATE' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <Video size={16} /> Content Studio
        </button>
        <button 
          onClick={() => setActiveTab('MANAGE')} 
          className={`flex items-center gap-2 text-sm font-medium transition-colors ${activeTab === 'MANAGE' ? 'text-white' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <MessageSquare size={16} /> Community
        </button>
      </div>

      <div className="flex-1 p-6 overflow-y-auto bg-darker">
        
        {/* RESEARCH TAB */}
        {activeTab === 'RESEARCH' && (
          <div className="space-y-6">
            <div className="bg-gray-900 p-6 rounded-xl border border-gray-800">
              <h3 className="text-white font-bold mb-4">Find Viral Topics</h3>
              <div className="flex gap-4">
                <input 
                  type="text" 
                  value={niche} 
                  onChange={e => setNiche(e.target.value)}
                  placeholder="Enter your niche (e.g. AI Marketing, Fitness, Finance)..."
                  className="flex-1 bg-black border border-gray-700 rounded-lg px-4 text-white"
                />
                <button onClick={handleResearch} disabled={loadingTrends} className="bg-primary text-darker font-bold px-6 rounded-lg hover:bg-green-400 disabled:opacity-50">
                  {loadingTrends ? <Loader2 className="animate-spin" /> : 'Analyze Trends'}
                </button>
              </div>
            </div>

            {trends && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 <div className="bg-gray-900 p-6 rounded-xl border border-gray-800">
                    <h4 className="text-primary font-bold mb-4">Market Analysis</h4>
                    <p className="text-gray-400 text-sm whitespace-pre-wrap">{trends.text}</p>
                 </div>
                 <div className="bg-gray-900 p-6 rounded-xl border border-gray-800">
                    <h4 className="text-secondary font-bold mb-4">Recommended Video Ideas</h4>
                    <div className="space-y-3">
                      {trends.ideas.map((idea, i) => (
                        <div key={i} className="flex justify-between items-center bg-black p-3 rounded border border-gray-800">
                          <span className="text-white text-sm">{idea}</span>
                          <button 
                            onClick={() => { setScriptTopic(idea); setActiveTab('CREATE'); }}
                            className="text-xs bg-gray-800 hover:bg-gray-700 text-white px-2 py-1 rounded"
                          >
                            Use This
                          </button>
                        </div>
                      ))}
                    </div>
                 </div>
              </div>
            )}
          </div>
        )}

        {/* CREATE TAB */}
        {activeTab === 'CREATE' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
            <div className="flex flex-col space-y-4">
              <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
                <label className="text-xs text-gray-500 uppercase font-bold mb-2 block">Video Topic</label>
                <input 
                  type="text" 
                  value={scriptTopic}
                  onChange={e => setScriptTopic(e.target.value)}
                  className="w-full bg-black border border-gray-700 rounded p-2 text-white mb-3"
                />
                
                {/* Veo Options */}
                <div className="bg-black/40 rounded p-3 mb-3 border border-gray-800">
                   <div className="flex items-center gap-2 mb-2 text-gray-400 text-xs font-bold uppercase">
                      <Settings size={12} /> Veo Settings
                   </div>
                   <div className="flex flex-col sm:flex-row gap-4">
                      <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer hover:text-white">
                          <div className={`w-4 h-4 rounded border flex items-center justify-center ${cinematicMode ? 'bg-secondary border-secondary' : 'border-gray-600 bg-transparent'}`}>
                            {cinematicMode && <Sparkles size={10} className="text-white" />}
                          </div>
                          <input type="checkbox" checked={cinematicMode} onChange={e => setCinematicMode(e.target.checked)} className="hidden" />
                          Cinematic Lighting
                      </label>
                      <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer hover:text-white">
                          <div className={`w-4 h-4 rounded border flex items-center justify-center ${highQuality ? 'bg-secondary border-secondary' : 'border-gray-600 bg-transparent'}`}>
                             {highQuality && <span className="text-[8px] font-bold text-white">4K</span>}
                          </div>
                          <input type="checkbox" checked={highQuality} onChange={e => setHighQuality(e.target.checked)} className="hidden" />
                          4K Resolution
                      </label>
                   </div>
                </div>

                <div className="flex gap-2">
                  <button onClick={handleScript} disabled={generatingScript || !scriptTopic} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg font-bold text-sm disabled:opacity-50 transition-all">
                    {generatingScript ? <Loader2 className="animate-spin mx-auto"/> : '1. Generate Script'}
                  </button>
                  <button onClick={handleVideo} disabled={generatingVideo || !scriptTopic} className="flex-1 bg-secondary hover:bg-purple-500 text-white py-3 rounded-lg font-bold text-sm disabled:opacity-50 transition-all">
                    {generatingVideo ? <Loader2 className="animate-spin mx-auto"/> : '2. Generate Veo Video'}
                  </button>
                </div>
              </div>

              <div className="flex-1 bg-gray-900 p-4 rounded-xl border border-gray-800 overflow-y-auto min-h-[300px]">
                 <h4 className="text-gray-400 text-xs uppercase font-bold mb-2">Script Preview</h4>
                 {script ? (
                   <div className="prose prose-invert text-sm"><ReactMarkdown>{script}</ReactMarkdown></div>
                 ) : (
                   <p className="text-gray-600 text-sm italic">Script will appear here...</p>
                 )}
              </div>
            </div>

            <div className="flex flex-col space-y-4">
               <div className="bg-black rounded-xl border border-gray-800 flex items-center justify-center aspect-video relative overflow-hidden group">
                  {generatingVideo && (
                    <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-10">
                      <Loader2 className="animate-spin text-secondary mb-2" size={40}/>
                      <p className="text-gray-400 text-xs font-mono">Veo is dreaming...</p>
                      <p className="text-gray-600 text-[10px] mt-1">Generating video frames</p>
                    </div>
                  )}
                  {videoUrl ? (
                    <video src={videoUrl} controls className="w-full h-full object-contain" />
                  ) : (
                    <div className="text-center">
                       <PlayCircle className="text-gray-700 mx-auto mb-2 group-hover:text-gray-600 transition-colors" size={48} />
                       <p className="text-gray-600 text-sm">No video generated yet</p>
                    </div>
                  )}
               </div>

               <div className="bg-gray-900 p-4 rounded-xl border border-gray-800">
                  <h4 className="text-gray-400 text-xs uppercase font-bold mb-4">Publishing Details</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Affiliate Links Inserted</span>
                      <span className="text-green-500">Yes (3)</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">SEO Tags</span>
                      <span className="text-green-500">Optimized</span>
                    </div>
                    <button className="w-full mt-2 bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded flex items-center justify-center gap-2">
                      <UploadCloud size={16} /> Schedule Upload to Channel
                    </button>
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* MANAGE TAB */}
        {activeTab === 'MANAGE' && (
          <div className="max-w-2xl mx-auto space-y-6">
             <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
               <h3 className="text-white font-bold mb-6">Recent Comments</h3>
               <div className="space-y-4">
                 {/* Mock Comment */}
                 <div className="bg-black p-4 rounded border border-gray-800">
                   <div className="flex justify-between mb-2">
                     <span className="text-blue-400 font-bold text-sm">@CryptoKing99</span>
                     <span className="text-gray-600 text-xs">2 mins ago</span>
                   </div>
                   <p className="text-gray-300 text-sm mb-3">Does this actually work for beginners? I've tried everything.</p>
                   <div className="pl-4 border-l-2 border-gray-700">
                      <button 
                        onClick={async () => {
                          const res = await generateReply("Does this actually work for beginners? I've tried everything.");
                          setCommentReply(res);
                        }}
                        className="text-xs text-primary hover:text-green-300 mb-2"
                      >
                        Generate AI Reply
                      </button>
                      {commentReply && (
                        <div className="bg-gray-800 p-2 rounded text-xs text-white">
                          {commentReply}
                          <div className="mt-2 flex justify-end">
                            <button className="text-blue-400 hover:text-blue-300 font-bold">Post Reply</button>
                          </div>
                        </div>
                      )}
                   </div>
                 </div>
               </div>
             </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default YouTubeAgent;