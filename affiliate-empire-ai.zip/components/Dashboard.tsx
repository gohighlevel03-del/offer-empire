import React from 'react';
import { 
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { ArrowUpRight, Users, DollarSign, MousePointer, Activity } from 'lucide-react';

const data = [
  { name: 'Mon', leads: 400, rev: 240 },
  { name: 'Tue', leads: 300, rev: 139 },
  { name: 'Wed', leads: 200, rev: 980 },
  { name: 'Thu', leads: 278, rev: 390 },
  { name: 'Fri', leads: 189, rev: 480 },
  { name: 'Sat', leads: 239, rev: 380 },
  { name: 'Sun', leads: 349, rev: 430 },
];

const StatCard = ({ title, value, icon: Icon, change, color }: any) => (
  <div className="bg-card border border-gray-800 p-6 rounded-xl hover:border-gray-600 transition-colors">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-gray-400 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-white">{value}</h3>
      </div>
      <div className={`p-2 rounded-lg ${color}`}>
        <Icon size={20} className="text-white" />
      </div>
    </div>
    <div className="mt-4 flex items-center text-sm">
      <span className="text-primary flex items-center font-bold">
        <ArrowUpRight size={14} className="mr-1" /> {change}
      </span>
      <span className="text-gray-500 ml-2">vs last week</span>
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Revenue" value="$12,450.00" icon={DollarSign} change="+14.2%" color="bg-green-600" />
        <StatCard title="Active Leads" value="1,234" icon={Users} change="+5.4%" color="bg-blue-600" />
        <StatCard title="Link Clicks" value="45,231" icon={MousePointer} change="+22.5%" color="bg-purple-600" />
        <StatCard title="Conversion Rate" value="3.2%" icon={Activity} change="+1.1%" color="bg-orange-600" />
      </div>

      {/* Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card border border-gray-800 p-6 rounded-xl">
          <h3 className="text-lg font-bold text-white mb-6">Revenue Growth</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00ff9d" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00ff9d" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', color: '#fff' }}
                  itemStyle={{ color: '#00ff9d' }}
                />
                <Area type="monotone" dataKey="rev" stroke="#00ff9d" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-card border border-gray-800 p-6 rounded-xl">
          <h3 className="text-lg font-bold text-white mb-6">Lead Acquisition</h3>
           <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', color: '#fff' }}
                />
                <Line type="monotone" dataKey="leads" stroke="#7000ff" strokeWidth={3} dot={{r: 4, fill: '#7000ff'}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Active Campaigns Table */}
      <div className="bg-card border border-gray-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-gray-800 flex justify-between items-center">
           <h3 className="text-lg font-bold text-white">Live Campaigns</h3>
           <button className="text-xs bg-gray-800 hover:bg-gray-700 px-3 py-1 rounded text-white transition-colors">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-400">
            <thead className="bg-gray-900/50 text-gray-200 font-semibold uppercase text-xs">
              <tr>
                <th className="px-6 py-4">Offer Name</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Network</th>
                <th className="px-6 py-4 text-right">Revenue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              <tr className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-white">Crypto Wealth 2.0</td>
                <td className="px-6 py-4"><span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs">Active</span></td>
                <td className="px-6 py-4">ClickBank</td>
                <td className="px-6 py-4 text-right text-white font-bold">$4,200</td>
              </tr>
              <tr className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-white">Keto Blast Gummies</td>
                <td className="px-6 py-4"><span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded text-xs">Optimizing</span></td>
                <td className="px-6 py-4">MaxWeb</td>
                <td className="px-6 py-4 text-right text-white font-bold">$1,850</td>
              </tr>
              <tr className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-white">AI Software Bundle</td>
                <td className="px-6 py-4"><span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs">Active</span></td>
                <td className="px-6 py-4">JVZoo</td>
                <td className="px-6 py-4 text-right text-white font-bold">$9,430</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;