import React, { useState } from 'react';
import { findLeads } from '../services/geminiService';
import { Lead } from '../types';
import { Users, Search, Loader2, Mail, Check, Download } from 'lucide-react';

const LeadGen: React.FC = () => {
  const [query, setQuery] = useState('');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;
    setLoading(true);
    try {
      const results = await findLeads(query);
      setLeads(results);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="bg-card border border-gray-700 rounded-xl p-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Users className="text-blue-400" size={24} />
          </div>
          <h2 className="text-2xl font-bold text-white">Automated Lead Scraper</h2>
        </div>
        <p className="text-gray-400 mb-6 ml-12">
          Use AI to scan the web for potential business leads, finding names and websites automatically.
        </p>

        <form onSubmit={handleSearch} className="relative ml-12">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g., 'Real Estate Agents in Miami', 'SaaS companies looking for affiliates'..."
            className="w-full bg-gray-900 text-white border border-gray-700 rounded-lg py-4 pl-4 pr-32 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
          />
          <button
            type="submit"
            disabled={loading}
            className="absolute right-2 top-2 bottom-2 bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 rounded-md transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : 'Find Leads'}
          </button>
        </form>
      </div>

      {leads.length > 0 && (
        <div className="bg-card border border-gray-700 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-gray-700 flex justify-between items-center bg-gray-900">
            <h3 className="font-bold text-white">Found {leads.length} Potential Leads</h3>
            <button className="text-xs flex items-center gap-1 text-gray-400 hover:text-white">
              <Download size={14} /> Export CSV
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-800 text-gray-400 font-semibold uppercase text-xs">
                <tr>
                  <th className="px-6 py-4">Lead Name / Business</th>
                  <th className="px-6 py-4">Source URL</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800 text-gray-300">
                {leads.map((lead, idx) => (
                  <tr key={idx} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 font-medium text-white">{lead.name}</td>
                    <td className="px-6 py-4 truncate max-w-[200px]">
                      <a href={lead.source} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline">
                        {lead.source}
                      </a>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs">New Found</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="bg-primary/10 text-primary hover:bg-primary hover:text-darker border border-primary/20 px-3 py-1 rounded text-xs font-bold transition-all">
                        Draft Email
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeadGen;