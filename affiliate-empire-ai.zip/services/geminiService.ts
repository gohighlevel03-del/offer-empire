import { GoogleGenAI, GenerativeModel, ChatSession, Part } from "@google/genai";

// --- API Key Management & Initialization ---

// Helper to handle Veo key selection
export const ensurePaidApiKey = async (): Promise<void> => {
  if (window.aistudio && window.aistudio.hasSelectedApiKey) {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await window.aistudio.openSelectKey();
    }
  }
};

const getAIClient = (): GoogleGenAI => {
  // Always create a new instance to pick up any dynamic key changes
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// --- Core Gemini Functions ---

export const generateMarketingCopy = async (prompt: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview', // Using Pro for better reasoning/copywriting
    contents: prompt,
    config: {
      systemInstruction: "You are a world-class direct response copywriter. Write high-converting, compliant ad copy.",
    }
  });
  return response.text || "No copy generated.";
};

export const findOffersWithGrounding = async (niche: string): Promise<{ text: string; sources: any[] }> => {
  const ai = getAIClient();
  const prompt = `Find the top high-ticket affiliate offers for the ${niche} niche currently trending. List their names, networks, and estimated payouts. Provide links where possible.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const text = response.text || "No results found.";
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  
  return { text, sources: chunks };
};

export const checkCompliance = async (textToCheck: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyze the following text for affiliate marketing compliance (FTC guidelines, ad network policies). Highlight risks and suggest fixes: \n\n"${textToCheck}"`,
  });
  return response.text || "Analysis failed.";
};

export const getLaunchPlan = async (goal: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create a detailed, step-by-step 30-day launch plan for an affiliate marketing campaign focusing on: ${goal}. Include daily tasks.`,
  });
  return response.text || "Plan generation failed.";
};

// --- Website Builder Services ---

export const generateWebsiteContent = async (niche: string, type: 'LANDING' | 'SALES' | 'OPTIN'): Promise<{headline: string, body: string, cta: string, seoTitle: string, seoDesc: string}> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Generate content for a ${type} page in the ${niche} niche. Return JSON with keys: headline, body (HTML formatted), cta, seoTitle, seoDesc.`,
    config: { responseMimeType: 'application/json' }
  });
  
  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    return { headline: "Error", body: "Could not generate content", cta: "Retry", seoTitle: "", seoDesc: "" };
  }
};

// --- YouTube Agent Services ---

export const researchYouTubeTrends = async (niche: string): Promise<{text: string, ideas: string[]}> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Find current trending topics and viral video ideas for the ${niche} niche on YouTube.`,
    config: { tools: [{ googleSearch: {} }] }
  });
  
  // Simple extraction of ideas from text for the list
  const ideas = response.text?.split('\n').filter(l => l.includes('*') || l.includes('-')).slice(0, 5).map(l => l.replace(/[*|-]/g, '').trim()) || [];
  return { text: response.text || "", ideas };
};

export const generateVideoScript = async (topic: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Write a compelling YouTube video script for: "${topic}". Include Intro (Hook), Body (3 main points), and Outro (CTA).`
  });
  return response.text || "";
};

export const generateReply = async (comment: string): Promise<string> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Write a friendly, engaging reply to this YouTube comment: "${comment}". Encourage them to subscribe or check the link in bio.`
  });
  return response.text || "";
};

// --- Lead Gen Services ---

export const findLeads = async (query: string): Promise<any[]> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Find potential leads for: ${query}. Look for business names and websites.`,
    config: { tools: [{ googleSearch: {} }] }
  });
  
  // Map grounding chunks to "leads"
  return response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => ({
    name: chunk.web?.title || "Unknown Lead",
    source: chunk.web?.uri || "Web Search",
    contactInfo: "Visit Site", // We can't scrape emails directly legally/easily without more tools, so we direct to site
    status: 'New'
  })) || [];
};

// --- Chat ---

export const createMentorSession = (): ChatSession => {
  const ai = getAIClient();
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are 'The Empire Builder', a ruthless but effective affiliate marketing mentor. You give direct, actionable advice. You focus on ROI, scale, and automation. Keep answers concise.",
    }
  });
};

// --- Multimedia Generation ---

export const editImage = async (base64Image: string, mimeType: string, prompt: string): Promise<string> => {
  const ai = getAIClient();
  
  const contents = {
    parts: [
      {
        inlineData: {
          data: base64Image,
          mimeType: mimeType,
        },
      },
      {
        text: prompt, // e.g. "Add a neon glow border", "Remove the background"
      },
    ],
  };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image', // Nano/Flash image for fast edits
    contents: contents,
  });

  // Extract image
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image returned from editing process.");
};

export const generateVeoVideo = async (prompt: string, base64Image?: string): Promise<string> => {
  // 1. Ensure paid key for Veo
  await ensurePaidApiKey();
  
  const ai = getAIClient();
  
  let operation;

  const config = {
    numberOfVideos: 1,
    resolution: '720p',
    aspectRatio: '16:9' // Landscape for YouTube/Ads
  };

  if (base64Image) {
    // Image-to-Video
    operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      image: {
        imageBytes: base64Image,
        mimeType: 'image/png', 
      },
      config: config
    });
  } else {
    // Text-to-Video
    operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      config: config
    });
  }

  // Poll for completion
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000)); // Poll every 5s
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) throw new Error("Video generation failed.");

  // Fetch the actual bytes using the API Key
  const response = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
};