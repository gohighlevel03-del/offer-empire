import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import OfferFinder from './components/OfferFinder';
import MarketingLab from './components/MarketingLab';
import MentorChat from './components/MentorChat';
import WebsiteBuilder from './components/WebsiteBuilder';
import YouTubeAgent from './components/YouTubeAgent';
import LeadGen from './components/LeadGen';
import { View } from './types';
import { checkCompliance, getLaunchPlan } from './services/geminiService';
import { Loader2, AlertTriangle, ShieldCheck, Wallet, Rocket } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  
  // Compliance State
  const [complianceText, setComplianceText] = useState('');
  const [complianceResult, setComplianceResult] = useState('');
  const [compLoading, setCompLoading] = useState(false);

  // Launch Plan State
  const [launchGoal, setLaunchGoal] = useState('');
  const [launchPlan, setLaunchPlan] = useState('');
  const [launchLoading, setLaunchLoading] = useState(false);

  // Handlers for simple views
  const handleCompliance = async () => {
    if (!complianceText) return;
    setCompLoading(true);
    try {
      const res = await checkCompliance(complianceText);
      setComplianceResult(res);
    } catch (e) { console.error(e); }
    finally { setCompLoading(false); }
  };

  const handleLaunchPlan = async () => {
    if (!launchGoal) return;
    setLaunchLoading(true);
    try {
      const res = await getLaunchPlan(launchGoal);
      setLaunchPlan(res);
    } catch (e) { console.error(e); }
    finally { setLaunchLoading(false); }
  };

  const renderContent = () => {
    switch (currentView) {
      case View.DASHBOARD: return <Dashboard />;
      case View.OFFER_FINDER: return <OfferFinder />;
      case View.WEBSITE_BUILDER: return <WebsiteBuilder />;
      case View.YOUTUBE_AGENT: return <YouTubeAgent />;
      case View.LEAD_GEN: return <LeadGen />;
      case View.MARKETING_LAB: return <MarketingLab />;
      case View.MENTOR: return <MentorChat />;
      
      // Simple views rendered inline for brevity
      case View.COMPLIANCE:
        return (
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <ShieldCheck className="text-primary" /> Compliance Officer AI
            </h2>
            <div className="bg-card border border-gray-700 p-6 rounded-xl">
              <textarea 
                className="w-full bg-gray-900 border border-gray-700 p-4 rounded-lg text-white min-h-[200px]"
                placeholder="Paste your landing page copy or email here for analysis..."
                value={complianceText}
                onChange={e => setComplianceText(e.target.value)}
              />
              <button 
                onClick={handleCompliance}
                disabled={compLoading}
                className="mt-4 bg-primary text-darker font-bold py-2 px-6 rounded hover:bg-green-400 transition flex items-center gap-2 disabled:opacity-50"
              >
                {compLoading ? <Loader2 className="animate-spin" /> : 'Run Compliance Check'}
              </button>
            </div>
            {complianceResult && (
              <div className="bg-gray-900 border border-gray-800 p-6 rounded-xl prose prose-invert max-w-none">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                   <AlertTriangle className="text-yellow-500" /> Report
                </h3>
                <ReactMarkdown>{complianceResult}</ReactMarkdown>
              </div>
            )}
          </div>
        );

      case View.LAUNCH_PLAN:
        return (
          <div className="max-w-4xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Rocket className="text-secondary" /> 30-Day Launch Strategy
            </h2>
             <div className="flex gap-4">
               <input 
                  type="text" 
                  className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white"
                  placeholder="What do you want to launch? (e.g., 'Weight loss affiliate blog using SEO')"
                  value={launchGoal}
                  onChange={e => setLaunchGoal(e.target.value)}
               />
               <button 
                 onClick={handleLaunchPlan}
                 disabled={launchLoading}
                 className="bg-secondary text-white font-bold px-6 rounded-lg hover:bg-purple-500 disabled:opacity-50"
               >
                 {launchLoading ? <Loader2 className="animate-spin" /> : 'Generate Plan'}
               </button>
             </div>
             {launchPlan && (
                <div className="bg-card border border-gray-700 p-8 rounded-xl prose prose-invert max-w-none">
                  <ReactMarkdown>{launchPlan}</ReactMarkdown>
                </div>
             )}
          </div>
        );

      case View.WALLET:
        return (
          <div className="max-w-3xl mx-auto text-center py-20">
            <div className="bg-card border border-gray-700 rounded-2xl p-10 inline-block w-full">
              <div className="mx-auto w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6">
                <Wallet size={40} className="text-green-400" />
              </div>
              <h2 className="text-4xl font-bold text-white mb-2">$24,593.12</h2>
              <p className="text-gray-400 mb-8">Total Available Balance</p>
              
              <div className="grid grid-cols-2 gap-4 mb-8">
                 <button className="bg-primary hover:bg-green-400 text-darker font-bold py-3 rounded-lg transition-colors">Withdraw to PayPal</button>
                 <button className="bg-gray-800 hover:bg-gray-700 text-white font-bold py-3 rounded-lg transition-colors">Add Funds</button>
              </div>
              
              <div className="text-left border-t border-gray-700 pt-6">
                <h3 className="text-white font-bold mb-4">Recent Transactions</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm text-gray-400">
                    <span>Payout: ClickBank (Weekly)</span>
                    <span className="text-green-400">+$4,200.00</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-400">
                    <span>Ad Spend: Facebook Ads</span>
                    <span className="text-red-400">-$1,250.00</span>
                  </div>
                   <div className="flex justify-between text-sm text-gray-400">
                    <span>Payout: MaxWeb</span>
                    <span className="text-green-400">+$850.00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-darker flex font-sans">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <main className="flex-1 ml-20 lg:ml-64 p-6 lg:p-10 overflow-x-hidden transition-all">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;